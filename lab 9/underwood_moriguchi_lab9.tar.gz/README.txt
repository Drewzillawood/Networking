run make
run ./receiver
run ./sender localhost server_IP

We essentially just send all 512 packets and any non-corrupted ones are what come back
