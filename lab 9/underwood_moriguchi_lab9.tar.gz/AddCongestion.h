void AddCongestion(char *data, double p);
